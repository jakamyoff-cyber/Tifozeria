// Client-side: chiama il proxy server /api/* e corregge il bug base64.
// Includere questo file al posto dello script inline che usava direttamente le API Google.

const delay = ms => new Promise(res => setTimeout(res, ms));

async function generateAndSetImage(prompt, elementId, loaderId, isBackground = false) {
  const element = document.getElementById(elementId);
  const loader = loaderId ? document.getElementById(loaderId) : null;
  if (!element) return;
  if (loader) loader.style.display = 'block';

  try {
    const res = await fetch('/api/generate-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt })
    });
    if (!res.ok) throw new Error(`Image API error ${res.status}`);
    const json = await res.json();
    const base64Data = json.base64;
    if (!base64Data) throw new Error('No base64 returned');

    const imageUrl = `data:image/png;base64,${base64Data}`;
    if (isBackground) {
      element.style.backgroundImage = `url('${imageUrl}')`;
    } else {
      element.src = imageUrl;
      element.style.opacity = 1;
    }
  } catch (err) {
    console.error('generateAndSetImage error', err);
    if (!isBackground && element) {
      element.alt = 'Immagine non disponibile';
      element.style.opacity = 1;
    }
  } finally {
    if (loader) loader.style.display = 'none';
  }
}

async function loadGeneratedImages() {
  generateAndSetImage("Cinematic Italian football stadium at night, premium streaming UI overlay", 'heroBackground', null, true);
  generateAndSetImage("Modern streaming UI screen showing Sports Menu, red accents", 'imgSport', 'loaderSport', false);
  generateAndSetImage("Detailed Electronic Program Guide UI mockup", 'imgEPG', 'loaderEPG', false);
  generateAndSetImage("Stylized sports event emblem, original art (avoid trademark logos)", 'imgVOD', 'loaderVOD', false);
  generateAndSetImage("Stylized Africa Cup inspired emblem, original art", 'imgLive', 'loaderLive', false);
}

async function analyzeQuery() {
  const queryInput = document.getElementById('analyzerQueryInput');
  const responseDiv = document.getElementById('analyzerResponse');
  const sourcesDiv = document.getElementById('analyzerSources');
  const analyzeButton = document.getElementById('analyzeButton');
  const userQuery = queryInput.value.trim();
  if (!userQuery) {
    responseDiv.innerHTML = '<p style="color:red; text-align:center;">Per favore, inserisci una domanda valida.</p>';
    sourcesDiv.style.display = 'none';
    return;
  }

  responseDiv.innerHTML = '<div class="loader" style="position:relative; margin: 20px auto;"></div><p style="text-align:center; margin-top:10px;">Analisi in corso... attendi.</p>';
  analyzeButton.disabled = true;
  analyzeButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analizzando...';

  try {
    const res = await fetch('/api/analyze', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: userQuery })
    });
    if (!res.ok) throw new Error('Analyze API failed');
    const json = await res.json();

    const candidate = json.candidates?.[0];
    const text = candidate?.content?.parts?.[0]?.text || json.resultText || 'Nessuna risposta generata.';
    responseDiv.innerHTML = `<strong>Risposta:</strong><br>${text.replace(/\n/g, '<br>')}`;

    const grounding = candidate?.groundingMetadata?.groundingAttributions || json.groundingAttributions;
    if (grounding && grounding.length) {
      sourcesDiv.innerHTML = '<strong>Fonti:</strong>';
      grounding.slice(0,3).forEach((g, i) => {
        const uri = g.web?.uri || g.uri;
        const title = g.web?.title || g.title || uri;
        if (uri) sourcesDiv.innerHTML += ` <a href="${uri}" target="_blank">(${i+1}) ${title}</a>`;
      });
      sourcesDiv.style.display = 'block';
    } else {
      sourcesDiv.style.display = 'none';
    }
  } catch (err) {
    console.error('analyzeQuery error', err);
    responseDiv.innerHTML = '<p style="color:red; text-align:center;">Errore di connessione. Riprova più tardi.</p>';
    sourcesDiv.style.display = 'none';
  } finally {
    analyzeButton.disabled = false;
    analyzeButton.innerHTML = '<i class="fas fa-paper-plane"></i> Analizza e Rispondi';
  }
}

async function submitOrder(form) {
  const submitButton = form.querySelector('.btn');
  const name = form.querySelector('input[type="text"]').value.trim();
  const email = form.querySelector('input[type="email"]').value.trim();
  const whatsapp = form.querySelector('input[type="tel"]').value.trim();
  const plan = document.getElementById('planSelector').value;
  const notes = form.querySelector('textarea').value.trim();

  const payload = { name, email, whatsapp, plan, notes, timestamp: new Date().toISOString() };

  submitButton.disabled = true;
  submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Inviando...';
  try {
    const res = await fetch('/api/order', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      const txt = await res.text();
      throw new Error(txt || 'Order endpoint error');
    }
    submitButton.innerHTML = '<i class="fas fa-check"></i> RICEVUTO!';
    submitButton.style.backgroundColor = '#25D366';
    form.reset();
    document.getElementById('planSelector').value = 'Tifo Power';
  } catch (err) {
    console.error('order submit error', err);
    const orderError = document.getElementById('orderError');
    if (orderError) { orderError.textContent = err.message || 'Errore invio ordine'; orderError.style.display = 'block'; }
    submitButton.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Errore invio';
    setTimeout(() => {
      submitButton.innerHTML = 'CONFERMA ORDINE';
      submitButton.style.backgroundColor = 'var(--primary-red)';
      submitButton.disabled = false;
    }, 3000);
    return;
  }
  setTimeout(() => {
    submitButton.innerHTML = 'CONFERMA ORDINE';
    submitButton.style.backgroundColor = 'var(--primary-red)';
    submitButton.disabled = false;
  }, 3000);
}

document.addEventListener('DOMContentLoaded', () => {
  const orderForm = document.getElementById('orderForm');
  if (orderForm) orderForm.addEventListener('submit', (e) => { e.preventDefault(); submitOrder(e.target); });
  try { loadGeneratedImages(); } catch (e) { console.warn('loadGeneratedImages non definita nel contesto HTML.'); }
});