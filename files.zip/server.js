/**
 * server.js - Proxy per Tifozeria (Node/Express)
 * - Protegge chiavi server-side
 * - Espone: POST /api/generate-image, /api/analyze, /api/order
 *
 * In produzione: usare client ufficiali Google, rate limiting più severo,
 * Secret Manager, logging/monitoring e validazione input.
 */
const express = require('express');
const fetch = require('node-fetch');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(helmet());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));

// Rate limiting base
const limiter = rateLimit({ windowMs: 60 * 1000, max: 60, standardHeaders: true, legacyHeaders: false });
app.use(limiter);

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;
const SHEET_WEBAPP_URL = process.env.SHEET_WEBAPP_URL;
const SHEET_SECRET = process.env.SHEET_SECRET;

if (!GOOGLE_API_KEY) console.warn('GOOGLE_API_KEY non impostata.');
if (!SHEET_WEBAPP_URL || !SHEET_SECRET) console.warn('SHEET_WEBAPP_URL o SHEET_SECRET mancanti.');

app.post('/api/generate-image', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt || typeof prompt !== 'string') return res.status(400).json({ error: 'prompt obbligatorio' });

    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/imagen-4.0-generate-001:predict?key=${GOOGLE_API_KEY}`;
    const payload = { instances: [{ prompt }], parameters: { sampleCount: 1 } };

    const r = await fetch(apiUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!r.ok) {
      const text = await r.text();
      console.error('Upstream image API error', r.status, text);
      return res.status(502).json({ error: 'upstream_error', details: text });
    }

    const json = await r.json();
    const base64Data = json?.predictions?.[0]?.bytesBase64Encoded;
    if (!base64Data) return res.status(502).json({ error: 'no_image_returned' });

    // Per demo ritorniamo il base64. In produzione salvare su GCS/S3 e restituire URL.
    res.json({ base64: base64Data });
  } catch (err) {
    console.error('generate-image error', err);
    res.status(500).json({ error: 'internal_error' });
  }
});

app.post('/api/analyze', async (req, res) => {
  try {
    const { query } = req.body;
    if (!query || typeof query !== 'string') return res.status(400).json({ error: 'query obbligatoria' });

    const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent?key=${GOOGLE_API_KEY}`;
    const systemPrompt = "Sei Tifo Analyzer, un assistente AI amichevole, conciso e molto esperto in servizi IPTV premium e sport. Rispondi in italiano.";

    const payload = { contents: [{ parts: [{ text: query }] }], systemInstruction: { parts: [{ text: systemPrompt }] } };

    const r = await fetch(apiUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!r.ok) {
      const text = await r.text();
      console.error('Upstream analyze API error', r.status, text);
      return res.status(502).json({ error: 'upstream_error', details: text });
    }

    const json = await r.json();
    res.json(json);
  } catch (err) {
    console.error('analyze error', err);
    res.status(500).json({ error: 'internal_error' });
  }
});

app.post('/api/order', async (req, res) => {
  try {
    if (!SHEET_WEBAPP_URL || !SHEET_SECRET) return res.status(500).json({ error: 'sheet_not_configured' });
    const payload = { ...req.body, secret: SHEET_SECRET };

    const r = await fetch(SHEET_WEBAPP_URL, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    if (!r.ok) {
      const text = await r.text();
      console.error('Sheet forward error', r.status, text);
      return res.status(502).json({ error: 'sheet_error', details: text });
    }
    try { await r.json(); } catch (_) {}
    res.json({ ok: true });
  } catch (err) {
    console.error('order proxy error', err);
    res.status(500).json({ error: 'internal_error' });
  }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => console.log(`API proxy listening on port ${PORT}`));