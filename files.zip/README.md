# Tifozeria - Proxy + Deploy su Cloud Run

Questo repo contiene:
- server.js: proxy Node/Express per proteggere le chiavi.
- public/js/api-client.js: client-side che chiama il proxy.
- Dockerfile + cloudbuild.yaml: per build e deploy su Google Cloud Run.

Prerequisiti:
- Google Cloud Project configurato.
- Abilitare API: Cloud Run, Cloud Build (se usi cloudbuild), Artifact Registry (opzionale).
- GOOGLE_API_KEY per Generative APIs.
- URL Web App Google Sheets (SHEET_WEBAPP_URL) e nuovo SHEET_SECRET.

Installazione locale:
1. Copia .env.example -> .env e riempi le variabili.
2. npm install
3. npm start

Deploy su Cloud Run (esempio con gcloud):
1. Autenticati e seleziona progetto:
   gcloud auth login
   gcloud config set project YOUR_PROJECT_ID

2. Abilita API:
   gcloud services enable run.googleapis.com cloudbuild.googleapis.com

3. Build & push (opzione: build con Cloud Build)
   gcloud builds submit --tag gcr.io/YOUR_PROJECT_ID/tifozeria-proxy

4. Deploy:
   gcloud run deploy tifozeria-proxy \
     --image gcr.io/YOUR_PROJECT_ID/tifozeria-proxy \
     --platform managed \
     --region europe-west1 \
     --allow-unauthenticated \
     --set-env-vars GOOGLE_API_KEY=REDACTED,SHEET_WEBAPP_URL=REDACTED,SHEET_SECRET=REDACTED,ALLOWED_ORIGIN=https://tuodominio.it

Consigli di sicurezza:
- Usare Secret Manager e montare segreti in Cloud Run (meglio che passare env vars).
- Limitare ALLOWED_ORIGIN al dominio.
- Ruotare immediatamente il SHEET_SECRET che era esposto nel client.
- Considerare CAPTCHA per il form ordini.

Se vuoi, posso:
- generare il diff/PR automaticamente (non posso farlo finché il repo resta vuoto o non ho accesso ai branch).
- guidarti passo‑passo con i comandi Git e Cloud SDK per creare branch, commit e PR.